(function($) {
  $(document).ready(function() {
     $("#adduserBut").click(function() {
       window.location.href="/adduser"; 
     });
  });
}(jQuery));
